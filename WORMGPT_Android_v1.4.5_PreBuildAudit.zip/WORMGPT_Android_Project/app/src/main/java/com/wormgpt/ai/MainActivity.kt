package com.wormgpt.ai

import android.content.Context
import android.accounts.AccountManager
import android.net.Uri
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.provider.OpenableColumns
import android.util.Base64
import android.os.Bundle
import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.work.WorkManager
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.ExistingWorkPolicy
import androidx.work.Data
import androidx.work.Constraints
import androidx.work.NetworkType
import androidx.work.BackoffPolicy
import androidx.work.ForegroundInfo
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.ProcessLifecycleOwner
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Link
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.widget.Toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.io.FileOutputStream
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.UUID
import java.util.concurrent.TimeUnit

// ثيم أحادي عميق — أسود احترافي + لمسة رمادي فاتح واحدة
private val Bg = Color(0xFF050506)
private val Surface = Color(0xFF0E0E10)
private val Surface2 = Color(0xFF16161A)
private val Accent = Color(0xFFD0D0D4)
private val TextMain = Color(0xFFEDEDEF)
private val TextMuted = Color(0xFF7A7A82)
private val BorderSoft = Color(0x14FFFFFF)
private val Glow = Color(0x22FFFFFF)
private val LightBg = Color(0xFFF3F3F4)
private val LightSurface = Color(0xFFFFFFFF)
private val LightSurface2 = Color(0xFFE8E8EA)
private val LightText = Color(0xFF121214)
private val LightMuted = Color(0xFF6B6B73)
private val ApiUrl = "https://wormgpt-silk.vercel.app/api/chat"
/** رابط يفتح التطبيق مباشرة */
private val AppDeepLink = "wormgpt://open"

private val AppShareMessage = """
🤖 جرب WORMGPT
مساحة الذكاء الخاصة بك

اضغط جرب WORMGPT وافتح التطبيق:
$AppDeepLink
""".trimIndent()

/** رابط محادثة محلي فريد (مش مربوط بموقع الـ API) */
private fun generateChatLink(sessionId: String): String {
    val short = sessionId.replace("-", "").take(10)
    val stamp = System.currentTimeMillis().toString(36)
    return "wormgpt://chat/$short-$stamp"
}

/** إزالة تنسيق Markdown الخفيف من النص العادي فقط؛ كتل الأكواد تُعرض منفصلة. */
private fun stripMarkdown(input: String): String {
    var value = input
    value = value.replace(Regex("\\*\\*(.+?)\\*\\*", RegexOption.DOT_MATCHES_ALL), "$1")
    value = value.replace(Regex("__(.+?)__", RegexOption.DOT_MATCHES_ALL), "$1")
    value = value.replace(Regex("(?<!\\w)\\*(.+?)\\*(?!\\w)", RegexOption.DOT_MATCHES_ALL), "$1")
    value = value.replace(Regex("`([^`]+)`"), "$1")
    value = value.replace(Regex("^#{1,6}\\s*", RegexOption.MULTILINE), "")
    return value.replace(Regex("\\n{3,}"), "\n\n").trim()
}

private data class ReplyPart(val code: Boolean, val language: String, val text: String)

/** Pick a stable paragraph direction from the first meaningful script character. */
private fun paragraphDirection(value: String): LayoutDirection {
    val firstStrong = value.firstOrNull { ch ->
        Character.getDirectionality(ch) == Character.DIRECTIONALITY_LEFT_TO_RIGHT ||
            Character.getDirectionality(ch) == Character.DIRECTIONALITY_RIGHT_TO_LEFT ||
            Character.getDirectionality(ch) == Character.DIRECTIONALITY_RIGHT_TO_LEFT_ARABIC
    } ?: return LayoutDirection.Rtl
    return if (Character.getDirectionality(firstStrong) == Character.DIRECTIONALITY_LEFT_TO_RIGHT)
        LayoutDirection.Ltr else LayoutDirection.Rtl
}

private fun splitReplyParts(source: String): List<ReplyPart> {
    val parts = mutableListOf<ReplyPart>()
    val fence = Regex("(?s)```([A-Za-z0-9_+.#-]*)[ \\t]*\\r?\\n(.*?)```")
    var cursor = 0
    fence.findAll(source).forEach { match ->
        if (match.range.first > cursor) {
            val prose = source.substring(cursor, match.range.first).trim()
            if (prose.isNotBlank()) parts += ReplyPart(false, "", prose)
        }
        parts += ReplyPart(true, match.groupValues[1].ifBlank { "CODE" }, match.groupValues[2].trimEnd())
        cursor = match.range.last + 1
    }
    if (cursor < source.length) {
        val tail = source.substring(cursor).trim()
        if (tail.isNotBlank()) parts += ReplyPart(false, "", tail)
    }
    if (parts.isEmpty() && source.isNotBlank()) parts += ReplyPart(false, "", source)
    return parts
}

/** نص المحادثة للمشاركة */
private fun buildChatShareText(session: ChatSession): String {
    val sb = StringBuilder()
    sb.appendLine("محادثة WORMGPT: ${session.title}")
    sb.appendLine("────────────────")
    session.messages.forEach { msg ->
        val who = if (msg.role == "user") "أنت" else "WORMGPT"
        sb.appendLine("$who:")
        sb.appendLine(msg.text)
        sb.appendLine()
    }
    sb.appendLine("────────────────")
    sb.appendLine(generateChatLink(session.id))
    return sb.toString().trim()
}

/** لا تُضمَّن أسرار البوت داخل APK؛ يتم تسليم الاقتراح إلى Telegram ليؤكده المستخدم. */
private suspend fun sendSuggestionToBot(context: Context, username: String?, text: String): String =
    withContext(Dispatchers.IO) { "OPEN_TG:dotbhzbot" }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(9, 10, 13)
        window.navigationBarColor = android.graphics.Color.rgb(9, 10, 13)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            @Suppress("DEPRECATION")
            setTaskDescription(android.app.ActivityManager.TaskDescription("WORMGPT", android.graphics.BitmapFactory.decodeResource(resources, R.drawable.launcher_foreground), android.graphics.Color.rgb(9, 10, 13)))
        }
        setContent { WormApp(applicationContext) }
    }
}

@Composable
private fun WormTheme(light: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (light) lightColorScheme(
            primary = Accent, background = LightBg, surface = LightSurface,
            onBackground = LightText, onSurface = LightText
        ) else darkColorScheme(
            primary = Accent, background = Bg, surface = Surface,
            onBackground = TextMain, onSurface = TextMain
        ),
        content = content
    )
}

data class ChatMessage(val id: String = UUID.randomUUID().toString(), val role: String, val text: String)
data class LocalAttachment(val name: String, val mimeType: String, val path: String, val size: Long, val relativePath: String = "")
data class ChatSession(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "محادثة جديدة",
    val messages: List<ChatMessage> = emptyList(),
    val updated: Long = System.currentTimeMillis()
)

private class LocalStore(context: Context) {
    private val p = context.getSharedPreferences("wormgpt_store", Context.MODE_PRIVATE)
    fun currentUser() = p.getString("active_user", null)
    fun isLoggedIn() = currentUser() != null
    fun createAccount(username: String, password: String): String? {
        val key = "account_${username.lowercase()}"
        if (p.contains(key)) return "اسم المستخدم مستخدم بالفعل على هذا الجهاز."
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val hash = hash(password, salt)
        p.edit().putString(key, salt.joinToString("") { "%02x".format(it) } + ":" + hash)
            .putString("active_user", username).apply()
        return null
    }
    fun login(username: String, password: String): String? {
        val stored = p.getString("account_${username.lowercase()}", null)
            ?: return "بيانات الدخول غير صحيحة."
        return try {
            val parts = stored.split(":")
            val salt = parts[0].chunked(2).map { it.toInt(16).toByte() }.toByteArray()
            if (hash(password, salt) != parts[1]) "بيانات الدخول غير صحيحة."
            else { p.edit().putString("active_user", username).apply(); null }
        } catch (_: Exception) { "تعذر التحقق من الحساب." }
    }
    fun logout() { p.edit().remove("active_user").apply() }
    fun clearSessions() {
        val u = currentUser() ?: return
        p.edit().remove("sessions_$u").apply()
    }
    fun deleteAccount() {
        val u = currentUser() ?: return
        p.edit()
            .remove("active_user")
            .remove("account_${u.lowercase()}")
            .remove("sessions_$u")
            .apply()
    }
    private fun hash(password: String, salt: ByteArray): String {
        val spec = javax.crypto.spec.PBEKeySpec(password.toCharArray(), salt, 120_000, 256)
        return javax.crypto.SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            .generateSecret(spec).encoded.joinToString("") { "%02x".format(it) }
    }
    fun loadSessions(): List<ChatSession> {
        val raw = p.getString("sessions_${currentUser()}", "[]") ?: "[]"
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val msgs = o.getJSONArray("messages")
                ChatSession(
                    id = o.getString("id"), title = o.getString("title"),
                    updated = o.optLong("updated"),
                    messages = (0 until msgs.length()).map { j ->
                        val m = msgs.getJSONObject(j)
                        ChatMessage(m.getString("id"), m.getString("role"), m.getString("text"))
                    }
                )
            }.sortedByDescending { it.updated }
        } catch (_: Exception) { emptyList() }
    }
    fun saveSessions(sessions: List<ChatSession>) {
        val arr = JSONArray()
        sessions.forEach { s ->
            val msgs = JSONArray()
            s.messages.forEach { m ->
                msgs.put(JSONObject().put("id", m.id).put("role", m.role).put("text", m.text))
            }
            arr.put(JSONObject().put("id", s.id).put("title", s.title)
                .put("updated", s.updated).put("messages", msgs))
        }
        p.edit().putString("sessions_${currentUser()}", arr.toString()).apply()
    }
}

private class WormApi {
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(5, TimeUnit.MINUTES)
        .build()

    suspend fun send(message: String, conversation: List<ChatMessage>, attachments: List<LocalAttachment> = emptyList()): String = withContext(Dispatchers.IO) {
            // The website's own "معلومات الواجهة" panel documents POST /api/chat
            // with no authentication. Keep the single-message field and also send
            // the conversation array so the server can use context when supported.
            val history = JSONArray()
            conversation.forEach { item ->
                history.put(JSONObject()
                    .put("role", if (item.role == "assistant") "assistant" else "user")
                    .put("content", item.text))
            }
            val attachmentArray = JSONArray()
            attachments.forEach { attachment ->
                val file = File(attachment.path)
                if (file.isFile && file.canRead()) {
                    val bytes = file.readBytes()
                    val item = JSONObject()
                        .put("name", attachment.name)
                        .put("relativePath", attachment.relativePath)
                        .put("mimeType", attachment.mimeType)
                        .put("size", bytes.size)
                        .put("contentBase64", Base64.encodeToString(bytes, Base64.NO_WRAP))
                    // Include readable text when possible; Base64 remains available for binary formats.
                    val readable = runCatching { bytes.toString(Charsets.UTF_8) }.getOrNull()
                    if (readable != null && readable.none { it == '\u0000' }) item.put("textContent", readable.take(300_000))
                    attachmentArray.put(item)
                }
            }
            val payload = JSONObject()
                .put("message", message)
                .put("messages", history)
                .put("attachments", attachmentArray)
            val body = payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
            val request = Request.Builder()
                .url(ApiUrl)
                .header("Accept", "application/json, text/plain, */*")
                .header("Content-Type", "application/json; charset=utf-8")
                .post(body)
                .build()
            client.newCall(request).execute().use { response ->
                val raw = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val detail = parseError(raw)
                    throw IOException("HTTP ${response.code}: ${detail.ifBlank { "تعذر إكمال الطلب" }}")
                }
                parseReply(raw)
            }
    }

    private fun parseError(raw: String): String = try {
        val obj = JSONObject(raw)
        obj.optString("error").ifBlank { obj.optString("message") }
    } catch (_: Exception) { raw.take(240) }

    private fun parseReply(raw: String): String {
        if (raw.isBlank()) return "وصل رد فارغ من الخدمة."

        val ignoredStages = setOf("start", "starting", "generating", "alive", "progress", "working", "thinking", "queued")

        // Decode one JSON string value without requiring the surrounding JSON
        // object to be valid (some streaming gateways emit unescaped newlines).
        fun decodeJsonString(source: String, quoteAt: Int): String? {
            if (quoteAt !in source.indices || source[quoteAt] != '"') return null
            val out = StringBuilder()
            var i = quoteAt + 1
            while (i < source.length) {
                val c = source[i++]
                when (c) {
                    '"' -> return out.toString()
                    '\\' -> {
                        if (i >= source.length) return null
                        when (val e = source[i++]) {
                            '"' -> out.append('"')
                            '\\' -> out.append('\\')
                            '/' -> out.append('/')
                            'b' -> out.append('\b')
                            'f' -> out.append('\u000c')
                            'n' -> out.append('\n')
                            'r' -> out.append('\r')
                            't' -> out.append('\t')
                            'u' -> {
                                if (i + 4 > source.length) return null
                                val code = source.substring(i, i + 4).toIntOrNull(16) ?: return null
                                out.append(code.toChar())
                                i += 4
                            }
                            else -> out.append(e)
                        }
                    }
                    else -> out.append(c)
                }
            }
            return null
        }

        fun extractTextField(source: String): String? {
            // Prefer the final assistant text field; ignore model, persona,
            // reasoning, mirror, status and other transport metadata.
            val keys = listOf("text", "reply", "answer", "output_text", "content")
            for (key in keys) {
                val pattern = Regex("\\\"${Regex.escape(key)}\\\"\\s*:")
                for (match in pattern.findAll(source)) {
                    var i = match.range.last + 1
                    while (i < source.length && source[i].isWhitespace()) i++
                    if (i < source.length && source[i] == '"') {
                        val value = decodeJsonString(source, i)?.trim().orEmpty()
                        if (value.isNotBlank()) return value
                    }
                }
            }
            return null
        }

        fun isProgressRecord(value: String): Boolean {
            val stage = Regex("\\\"stage\\\"\\s*:\\s*\\\"([^\\\"]+)\\\"")
                .find(value)?.groupValues?.getOrNull(1)?.lowercase()
            return stage in ignoredStages
        }

        fun cleanCandidate(value: String): String? {
            val candidate = value.trim().removePrefix("data:").trim()
            if (candidate.isBlank() || candidate == "[DONE]" || isProgressRecord(candidate)) return null
            // If a JSON envelope is present, never show the envelope itself.
            if (candidate.startsWith("{") || candidate.startsWith("[")) {
                extractTextField(candidate)?.let { nested ->
                    if (nested.startsWith("{") || nested.startsWith("[")) {
                        cleanCandidate(nested)?.let { return it }
                    }
                    return nested.takeIf { it.isNotBlank() }
                }
                return null
            }
            return candidate
        }

        // First try the complete response. This handles compact and pretty JSON.
        cleanCandidate(raw)?.let { return it }
        extractTextField(raw)?.let { extracted ->
            cleanCandidate(extracted)?.let { return it }
            if (extracted.isNotBlank() && !extracted.startsWith("{")) return extracted
        }

        // Then handle SSE / NDJSON: progress events are discarded and only
        // the actual text from the final assistant event is retained.
        val textChunks = mutableListOf<String>()
        raw.lineSequence().forEach { original ->
            var line = original.trim()
            if (line.isBlank() || line.startsWith(":") || line.startsWith("event:", true)) return@forEach
            if (line.startsWith("data:", true)) line = line.substringAfter(':').trim()
            if (line.isBlank() || line == "[DONE]" || isProgressRecord(line)) return@forEach
            val extracted = extractTextField(line)
            if (extracted != null) {
                if (extracted.isNotBlank()) textChunks.add(extracted)
            } else if (!line.startsWith("{") && !line.startsWith("[")) {
                textChunks.add(line)
            }
        }
        textChunks.lastOrNull { it.isNotBlank() }?.let { return it.trim() }

        // Last-resort guard: return a clear message, never raw protocol JSON.
        return "وصل رد من الخدمة، لكن تنسيقه غير مفهوم. جرّب إرسال رسالتك مرة أخرى."
    }

}

private fun hasValidatedInternet(context: Context): Boolean {
    val manager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
    val network = manager.activeNetwork ?: return false
    val capabilities = manager.getNetworkCapabilities(network) ?: return false
    return capabilities.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
        capabilities.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_VALIDATED)
}

@Composable
private fun WormApp(context: Context) {
    val store = remember { LocalStore(context) }
    var loggedIn by remember { mutableStateOf(store.isLoggedIn()) }
    var light by remember { mutableStateOf(context.getSharedPreferences("wormgpt_store", Context.MODE_PRIVATE).getBoolean("light_theme", false)) }
    val notificationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    var internetAvailable by remember { mutableStateOf(hasValidatedInternet(context)) }
    DisposableEffect(context) {
        val connectivity = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                internetAvailable = hasValidatedInternet(context)
            }
            override fun onCapabilitiesChanged(network: Network, capabilities: NetworkCapabilities) {
                internetAvailable = capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                    capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
            }
            override fun onLost(network: Network) {
                internetAvailable = hasValidatedInternet(context)
            }
        }
        try { connectivity.registerDefaultNetworkCallback(callback) } catch (_: Exception) { }
        internetAvailable = hasValidatedInternet(context)
        onDispose { try { connectivity.unregisterNetworkCallback(callback) } catch (_: Exception) { } }
    }
    WormTheme(light) {
        if (!internetAvailable) {
            // Original offline wording, shown on a plain black full-screen page.
            Box(
                modifier = Modifier.fillMaxSize().background(androidx.compose.ui.graphics.Color.Black),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "حدث خطأ في الاتصال بموقع WORMGPT. تأكد من الإنترنت وحاول مرة أخرى.",
                    color = androidx.compose.ui.graphics.Color.White,
                    fontSize = 15.sp,
                    modifier = Modifier.padding(horizontal = 28.dp),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }
        } else if (loggedIn) {
            ChatHome(store, light, { value ->
                light = value
                context.getSharedPreferences("wormgpt_store", Context.MODE_PRIVATE).edit().putBoolean("light_theme", value).apply()
            }) { store.logout(); loggedIn = false }
        } else {
            AuthScreen(store, light) { loggedIn = true }
        }
    }
}

@Composable
private fun AuthScreen(store: LocalStore, light: Boolean, onSuccess: () -> Unit) {
    var createMode by remember { mutableStateOf(false) }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    val context = LocalContext.current
    val googleAccountPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            val accountName = result.data?.getStringExtra(AccountManager.KEY_ACCOUNT_NAME)
            if (!accountName.isNullOrBlank()) {
                // اختيار حساب من نافذة أندرويد فقط؛ لا يتم التحقق من الهوية أو إنشاء جلسة Google.
                context.getSharedPreferences("wormgpt_store", Context.MODE_PRIVATE)
                    .edit().putString("google_picker_account", accountName).apply()
                onSuccess()
            }
        }
    }

    val textColor = TextMain
    val muted = TextMuted

    Box(modifier = Modifier.fillMaxSize().background(Bg)) {
        // هالة ضوء خفيفة من الأعلى — عمق بصري بدون كروت مربعة
        Box(
            Modifier
                .fillMaxWidth()
                .height(320.dp)
                .background(
                    Brush.radialGradient(
                        colors = listOf(Color(0x18FFFFFF), Color.Transparent),
                        radius = 520f
                    )
                )
        )
        Box(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .height(220.dp)
                .background(
                    Brush.verticalGradient(
                        listOf(Color.Transparent, Color(0x40000000))
                    )
                )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 32.dp)
                .padding(top = 72.dp, bottom = 40.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // لوجو دائري بإطار ناعم
            Box(contentAlignment = Alignment.Center) {
                Box(
                    Modifier
                        .size(118.dp)
                        .background(
                            Brush.radialGradient(
                                listOf(Color(0x28FFFFFF), Color.Transparent)
                            ),
                            CircleShape
                        )
                )
                Image(
                    painter = painterResource(id = R.drawable.wormgpt_logo),
                    contentDescription = "WormGPT",
                    modifier = Modifier
                        .size(96.dp)
                        .clip(CircleShape)
                        .border(1.dp, BorderSoft, CircleShape),
                    contentScale = ContentScale.Crop
                )
            }

            Spacer(Modifier.height(22.dp))

            Text(
                "WORMGPT",
                fontSize = 28.sp,
                fontWeight = FontWeight.Light,
                color = textColor,
                letterSpacing = 8.sp
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "مساحة الذكاء الخاصة بك",
                color = muted,
                fontSize = 13.sp,
                letterSpacing = 0.5.sp
            )

            Spacer(Modifier.height(48.dp))

            Text(
                if (createMode) "إنشاء حساب" else "تسجيل الدخول",
                fontSize = 20.sp,
                fontWeight = FontWeight.Medium,
                color = textColor,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(6.dp))
            Text(
                if (createMode) "حساب محلي على جهازك فقط"
                else "مرحباً بعودتك",
                color = muted,
                fontSize = 13.sp,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(28.dp))

            // حقول بدون كرت ثقيل — خطوط ناعمة
            Text("اسم المستخدم", color = muted, fontSize = 11.sp, modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp))
            OutlinedTextField(
                value = username,
                onValueChange = { username = it; error = "" },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                singleLine = true,
                shape = RoundedCornerShape(28.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0x55FFFFFF),
                    unfocusedBorderColor = BorderSoft,
                    focusedContainerColor = Surface,
                    unfocusedContainerColor = Surface,
                    cursorColor = Accent,
                    focusedTextColor = textColor,
                    unfocusedTextColor = textColor
                ),
                placeholder = { Text("username", color = Color(0xFF4A4A52), fontSize = 14.sp) }
            )

            Spacer(Modifier.height(16.dp))

            Text("كلمة المرور", color = muted, fontSize = 11.sp, modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp))
            OutlinedTextField(
                value = password,
                onValueChange = { password = it; error = "" },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                singleLine = true,
                visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                shape = RoundedCornerShape(28.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0x55FFFFFF),
                    unfocusedBorderColor = BorderSoft,
                    focusedContainerColor = Surface,
                    unfocusedContainerColor = Surface,
                    cursorColor = Accent,
                    focusedTextColor = textColor,
                    unfocusedTextColor = textColor
                ),
                placeholder = { Text("••••••••", color = Color(0xFF4A4A52), fontSize = 14.sp) },
                trailingIcon = {
                    IconButton(onClick = { passwordVisible = !passwordVisible }) {
                        Icon(
                            if (passwordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                            null,
                            tint = muted
                        )
                    }
                }
            )

            if (error.isNotBlank()) {
                Spacer(Modifier.height(12.dp))
                Text(error, color = Color(0xFFFF8E8E), fontSize = 12.sp, modifier = Modifier.fillMaxWidth())
            }

            Spacer(Modifier.height(28.dp))

            Button(
                onClick = {
                    val u = username.trim()
                    error = when {
                        u.length < 3 -> "اسم المستخدم يجب أن يكون 3 أحرف على الأقل."
                        password.length < 6 -> "كلمة المرور يجب أن تكون 6 أحرف على الأقل."
                        else -> if (createMode) store.createAccount(u, password) ?: "" else store.login(u, password) ?: ""
                    }
                    if (error.isEmpty()) onSuccess()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .border(1.dp, BorderSoft, RoundedCornerShape(28.dp)),
                shape = RoundedCornerShape(28.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Surface2,
                    contentColor = TextMain
                ),
                elevation = ButtonDefaults.buttonElevation(0.dp)
            ) {
                Text(
                    if (createMode) "إنشاء الحساب" else "دخول",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 15.sp,
                    letterSpacing = 1.sp
                )
            }

            if (!createMode) {
                Spacer(Modifier.height(14.dp))
                OutlinedButton(
                    onClick = {
                        try {
                            val pickerIntent = AccountManager.newChooseAccountIntent(
                                null,
                                null,
                                arrayOf("com.google"),
                                "اختيار حساب Google للمتابعة",
                                null,
                                null,
                                null
                            )
                            googleAccountPicker.launch(pickerIntent)
                        } catch (_: Exception) {
                            error = "تعذر فتح نافذة حسابات Google على هذا الجهاز."
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(28.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = textColor),
                    border = androidx.compose.foundation.BorderStroke(1.dp, BorderSoft)
                ) {
                    Text("G", color = Color(0xFF4285F4), fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(10.dp))
                    Text("متابعة باستخدام Google", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                }
            }

            Spacer(Modifier.height(18.dp))

            TextButton(onClick = { createMode = !createMode; error = "" }) {
                Text(
                    if (createMode) "لديك حساب؟ سجّل الدخول" else "ليس لديك حساب؟ أنشئ حساباً",
                    color = muted,
                    fontSize = 13.sp
                )
            }

            Spacer(Modifier.height(36.dp))

            Text(
                "اختيار Google يفتح نافذة الحسابات ويُستخدم كدخول محلي فقط",
                color = Color(0xFF4A4A52),
                fontSize = 11.sp,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun fieldColors(light: Boolean) = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Accent, unfocusedBorderColor = Surface2,
    focusedLabelColor = Accent, unfocusedLabelColor = TextMuted,
    cursorColor = Accent, focusedTextColor = TextMain, unfocusedTextColor = TextMain
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ChatHome(store: LocalStore, light: Boolean, onThemeChange: (Boolean) -> Unit, onLogout: () -> Unit) {
    val scope = rememberCoroutineScope()
    val api = remember { WormApi() }
    val pageBg = if (light) LightBg else Bg
    val panel = if (light) LightSurface else Surface
    val panel2 = if (light) LightSurface2 else Surface2
    val mainText = if (light) LightText else TextMain
    val mutedText = if (light) LightMuted else TextMuted
    val context = androidx.compose.ui.platform.LocalContext.current
    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    var appInForeground by remember { mutableStateOf(true) }
    DisposableEffect(lifecycleOwner) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            appInForeground = event == androidx.lifecycle.Lifecycle.Event.ON_RESUME
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    var sessions by remember { mutableStateOf(store.loadSessions()) }
    var currentId by remember { mutableStateOf(sessions.firstOrNull()?.id ?: "") }
    var draft by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    var selectedAttachments by remember { mutableStateOf<List<LocalAttachment>>(emptyList()) }
    var showSettings by remember { mutableStateOf(false) }
    var generatedLink by remember { mutableStateOf<String?>(null) }
    var showSuggestion by remember { mutableStateOf(false) }
    var suggestionText by remember { mutableStateOf("") }
    var suggestionSending by remember { mutableStateOf(false) }
    var attachmentMenu by remember { mutableStateOf(false) }
    val current = sessions.firstOrNull { it.id == currentId }
    LaunchedEffect(appInForeground) {
        while (appInForeground) {
            kotlinx.coroutines.delay(1200)
            sessions = store.loadSessions()
        }
    }
    fun copyUriToCache(uri: Uri, relativePath: String = ""): LocalAttachment? {
        return runCatching {
            val resolver = context.contentResolver
            val displayName = resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) cursor.getString(0) else null
            } ?: uri.lastPathSegment?.substringAfterLast('/') ?: "attachment"
            val mime = resolver.getType(uri) ?: java.net.URLConnection.guessContentTypeFromName(displayName) ?: "application/octet-stream"
            val target = File(context.cacheDir, "attachments").apply { mkdirs() }
            val safeName = displayName.replace(Regex("[^A-Za-z0-9._-]"), "_").take(100).ifBlank { "attachment" }
            val output = File(target, "${UUID.randomUUID()}_$safeName")
            resolver.openInputStream(uri)?.use { input -> FileOutputStream(output).use { out -> input.copyTo(out) } } ?: return null
            LocalAttachment(displayName, mime, output.absolutePath, output.length(), relativePath)
        }.getOrNull()
    }
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris: List<Uri> ->
        if (uris.isNotEmpty()) scope.launch {
            val copied = withContext(Dispatchers.IO) { uris.mapNotNull { copyUriToCache(it) } }
            selectedAttachments = selectedAttachments + copied
        }
    }
    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        if (uri != null) scope.launch {
            val copied = withContext(Dispatchers.IO) {
                val result = mutableListOf<LocalAttachment>()
                fun walk(directory: DocumentFile, prefix: String) {
                    directory.listFiles().forEach { child ->
                        val relative = if (prefix.isBlank()) child.name.orEmpty() else "$prefix/${child.name.orEmpty()}"
                        if (child.isDirectory) walk(child, relative)
                        else if (child.isFile) copyUriToCache(child.uri, relative)?.let { result.add(it) }
                    }
                }
                DocumentFile.fromTreeUri(context, uri)?.let { walk(it, it.name.orEmpty()) }
                result
            }
            selectedAttachments = selectedAttachments + copied
        }
    }

    fun persist(updated: List<ChatSession>) {
        sessions = updated
        store.saveSessions(updated)
    }
    fun newChat() {
        val s = ChatSession()
        persist(listOf(s) + sessions)
        currentId = s.id
        draft = ""
        selectedAttachments.forEach { File(it.path).delete() }
        selectedAttachments = emptyList()
    }
    fun submit() {
        val msg = draft.trim()
        if (msg.isEmpty() || busy) return
        // Keep the original chat error bubble from the pre-network-gate build.
        // Do not replace the whole app with a separate offline screen.
        if (!hasValidatedInternet(context)) {
            val offlineText = "حدث خطأ في الاتصال بموقع WORMGPT. تأكد من الإنترنت وحاول مرة أخرى."
            val attachmentSummaryOffline = if (selectedAttachments.isNotEmpty()) {
                "\n\n[مرفقات: ${selectedAttachments.joinToString("، ") { it.relativePath.ifBlank { it.name } }}]"
            } else ""
            val activeOffline = current ?: ChatSession()
            val offlineMessages = activeOffline.messages +
                ChatMessage(role = "user", text = msg + attachmentSummaryOffline) +
                ChatMessage(role = "assistant", text = offlineText)
            val failedOffline = activeOffline.copy(
                title = if (activeOffline.messages.isEmpty()) msg.take(36) else activeOffline.title,
                messages = offlineMessages,
                updated = System.currentTimeMillis()
            )
            persist(listOf(failedOffline) + sessions.filterNot { it.id == failedOffline.id })
            currentId = failedOffline.id
            draft = ""
            selectedAttachments.forEach { File(it.path).delete() }
            selectedAttachments = emptyList()
            return
        }
        val attachmentSummary = if (selectedAttachments.isNotEmpty()) {
            "\n\n[مرفقات: ${selectedAttachments.joinToString("، ") { it.relativePath.ifBlank { it.name } }}]"
        } else ""
        val outgoing = msg + attachmentSummary
        val active = current ?: ChatSession()
        val userMessage = ChatMessage(role = "user", text = outgoing)
        val updatedMessages = active.messages + userMessage
        val updatedSession = active.copy(
            title = if (active.messages.isEmpty()) msg.take(36) else active.title,
            messages = updatedMessages, updated = System.currentTimeMillis()
        )
        persist(listOf(updatedSession) + sessions.filterNot { it.id == updatedSession.id })
        currentId = updatedSession.id
        draft = ""
        val manifestFile = if (selectedAttachments.isNotEmpty()) {
            File(context.cacheDir, "attachments/${UUID.randomUUID()}_manifest.json").apply {
                parentFile?.mkdirs()
                writeText(JSONArray().apply {
                    selectedAttachments.forEach { item ->
                        put(JSONObject().put("name", item.name).put("mimeType", item.mimeType)
                            .put("path", item.path).put("size", item.size).put("relativePath", item.relativePath))
                    }
                }.toString())
            }
        } else null
        selectedAttachments = emptyList()
        busy = true
        val request = OneTimeWorkRequestBuilder<WormReplyWorker>()
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
            .setInputData(Data.Builder().putString("session_id", updatedSession.id).putString("message", msg).putString("manifest_path", manifestFile?.absolutePath.orEmpty()).build())
            .build()
        WorkManager.getInstance(context).enqueueUniqueWork(
            "wormgpt_reply_${updatedSession.id}", ExistingWorkPolicy.APPEND_OR_REPLACE, request
        )
        scope.launch {
            // Poll durable work; it continues even if the app is swiped away.
            while (true) {
                val info = withContext(Dispatchers.IO) {
                    WorkManager.getInstance(context).getWorkInfoById(request.id).get()
                }
                if (info?.state?.isFinished == true) {
                    sessions = store.loadSessions()
                    busy = false
                    break
                }
                kotlinx.coroutines.delay(700)
            }
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = panel,
                modifier = Modifier.width(310.dp)
            ) {
                Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("WORMGPT", fontWeight = FontWeight.Black, fontSize = 20.sp, modifier = Modifier.weight(1f))
                    IconButton(onClick = { scope.launch { drawerState.close() } }) { Icon(Icons.Default.Close, "إغلاق") }
                }
                Button(
                    onClick = { newChat(); scope.launch { drawerState.close() } },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp)
                        .border(1.dp, BorderSoft, RoundedCornerShape(14.dp)),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Surface2,
                        contentColor = TextMain
                    ),
                    elevation = ButtonDefaults.buttonElevation(0.dp)
                ) {
                    Icon(Icons.Default.Edit, null, tint = TextMain)
                    Spacer(Modifier.width(8.dp))
                    Text("محادثة جديدة")
                }
                Spacer(Modifier.height(18.dp))
                Text("المحادثات", color = mutedText, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 18.dp))
                Spacer(Modifier.height(8.dp))
                LazyColumn(Modifier.weight(1f)) {
                    items(sessions, key = { it.id }) { session ->
                        Row(
                            Modifier.fillMaxWidth().clickable {
                                currentId = session.id; scope.launch { drawerState.close() }
                            }.padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.ChatBubbleOutline, null, tint = TextMuted, modifier = Modifier.size(19.dp))
                            Spacer(Modifier.width(10.dp))
                            Text(session.title, color = mainText, maxLines = 1, modifier = Modifier.weight(1f), fontSize = 13.sp)
                            IconButton(onClick = {
                                val remaining = sessions.filterNot { it.id == session.id }
                                persist(remaining)
                                if (currentId == session.id) currentId = remaining.firstOrNull()?.id ?: ""
                            }) { Icon(Icons.Default.DeleteOutline, "حذف", tint = TextMuted) }
                        }
                    }
                }
                Divider(color = panel2)
                // مشاركة التطبيق — خارج الإعدادات (القائمة الجانبية)
                NavigationDrawerItem(
                    label = { Text("مشاركة التطبيق") },
                    selected = false,
                    icon = {
                        Image(
                            painter = painterResource(id = R.drawable.wormgpt_logo),
                            contentDescription = null,
                            modifier = Modifier.size(24.dp).clip(RoundedCornerShape(6.dp)),
                            contentScale = ContentScale.Crop
                        )
                    },
                    onClick = {
                        scope.launch { drawerState.close() }
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_SUBJECT, "جرب WORMGPT")
                            putExtra(Intent.EXTRA_TEXT, AppShareMessage)
                        }
                        context.startActivity(Intent.createChooser(send, "مشاركة التطبيق عبر"))
                    },
                    modifier = Modifier.padding(horizontal = 10.dp)
                )
                NavigationDrawerItem(
                    label = { Text("الإعدادات") }, selected = false,
                    icon = { Icon(Icons.Default.Settings, null) },
                    onClick = { showSettings = true; scope.launch { drawerState.close() } },
                    modifier = Modifier.padding(horizontal = 10.dp)
                )
                NavigationDrawerItem(
                    label = { Text("تسجيل الخروج") }, selected = false,
                    icon = { Icon(Icons.Default.Logout, null) },
                    onClick = onLogout, modifier = Modifier.padding(horizontal = 10.dp)
                )
                Spacer(Modifier.height(12.dp))
            }
        },
        gesturesEnabled = true
    ) {
        Scaffold(
            containerColor = pageBg,
            topBar = {
                CenterAlignedTopAppBar(
                    title = { Text("WORMGPT", fontWeight = FontWeight.Black, letterSpacing = 1.5.sp) },
                    navigationIcon = { IconButton(onClick = { scope.launch { drawerState.open() } }) { Icon(Icons.Default.Menu, "القائمة") } },
                    actions = {
                        // نسخ رابط المحادثة — أيقونة نسخ واضحة
                        IconButton(onClick = {
                            val session = sessions.firstOrNull { it.id == currentId }
                            if (session == null) {
                                Toast.makeText(context, "لا توجد محادثة", Toast.LENGTH_SHORT).show()
                            } else {
                                val link = generateChatLink(session.id)
                                generatedLink = link
                                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                cm.setPrimaryClip(ClipData.newPlainText("WORMGPT Chat Link", link))
                                Toast.makeText(context, "تم نسخ رابط المحادثة", Toast.LENGTH_SHORT).show()
                            }
                        }) {
                            Icon(
                                Icons.Default.ContentCopy,
                                contentDescription = "نسخ رابط المحادثة",
                                tint = Accent
                            )
                        }
                        // مشاركة المحادثة (يفتح اختيار التطبيقات)
                        IconButton(onClick = {
                            val session = sessions.firstOrNull { it.id == currentId }
                            if (session == null || session.messages.isEmpty()) {
                                Toast.makeText(context, "المحادثة فارغة", Toast.LENGTH_SHORT).show()
                            } else {
                                val text = buildChatShareText(session)
                                val send = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_SUBJECT, session.title)
                                    putExtra(Intent.EXTRA_TEXT, text)
                                }
                                context.startActivity(
                                    Intent.createChooser(send, "مشاركة المحادثة عبر")
                                )
                            }
                        }) {
                            Icon(
                                Icons.Default.Share,
                                contentDescription = "مشاركة المحادثة"
                            )
                        }
                        IconButton(onClick = { newChat() }) {
                            Icon(Icons.Default.Edit, contentDescription = "محادثة جديدة")
                        }
                    },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = pageBg, titleContentColor = TextMain, navigationIconContentColor = TextMain, actionIconContentColor = TextMain)
                )
            },
            bottomBar = {
                Column(Modifier.fillMaxWidth().background(panel).padding(horizontal = 10.dp, vertical = 9.dp)) {
                    if (selectedAttachments.isNotEmpty()) {
                        LazyColumn(Modifier.fillMaxWidth().heightIn(max = 112.dp).padding(start = 40.dp, bottom = 7.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            items(selectedAttachments, key = { it.path }) { attachment ->
                                Surface(color = panel2, shape = RoundedCornerShape(10.dp)) {
                                    Row(Modifier.fillMaxWidth().padding(horizontal = 9.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.AttachFile, null, tint = Accent, modifier = Modifier.size(15.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(attachment.relativePath.ifBlank { attachment.name }, color = mutedText, fontSize = 10.sp, maxLines = 1)
                                            Text("${(attachment.size / 1024).coerceAtLeast(1)} KB · ${attachment.mimeType}", color = mutedText.copy(alpha = .7f), fontSize = 9.sp, maxLines = 1)
                                        }
                                        IconButton(onClick = { File(attachment.path).delete(); selectedAttachments = selectedAttachments.filterNot { it.path == attachment.path } }, modifier = Modifier.size(24.dp)) {
                                            Icon(Icons.Default.Close, null, tint = mutedText, modifier = Modifier.size(15.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // حقل الكتابة على اليمين، وزر الإرسال على اليسار في واجهة RTL.
                        androidx.compose.runtime.CompositionLocalProvider(
                            androidx.compose.ui.platform.LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Rtl
                        ) {
                            Row(
                                modifier = Modifier
                                    .weight(1f)
                                    .heightIn(min = 52.dp, max = 124.dp)
                                    .background(Surface, RoundedCornerShape(24.dp))
                                    .border(1.dp, BorderSoft, RoundedCornerShape(24.dp))
                                    .padding(start = 6.dp, end = 14.dp, top = 5.dp, bottom = 5.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                BasicTextField(
                                    value = draft,
                                    onValueChange = { draft = it },
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxWidth()
                                        .heightIn(min = 42.dp, max = 108.dp),
                                    textStyle = androidx.compose.ui.text.TextStyle(
                                        color = mainText,
                                        fontSize = 15.sp,
                                        textAlign = TextAlign.Start,
                                        textDirection = TextDirection.ContentOrRtl
                                    ),
                                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                                    keyboardActions = KeyboardActions(onSend = { submit() }),
                                    maxLines = 4,
                                    decorationBox = { inner ->
                                        Box(
                                            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 9.dp),
                                            contentAlignment = Alignment.CenterStart
                                        ) {
                                            if (draft.isEmpty()) {
                                                Text(
                                                    text = "Message WORMGPT...",
                                                    color = mutedText,
                                                    fontSize = 15.sp
                                                )
                                            }
                                            inner()
                                        }
                                    }
                                )
                                IconButton(
                                    onClick = { filePicker.launch(arrayOf("*/*")) },
                                    modifier = Modifier.size(38.dp)
                                ) {
                                    Icon(Icons.Default.AttachFile, "إرفاق ملفات", tint = mutedText, modifier = Modifier.size(21.dp))
                                }
                            }
                        }
                        Spacer(Modifier.width(8.dp))
                        IconButton(
                            onClick = { submit() },
                            enabled = !busy && draft.isNotBlank(),
                            modifier = Modifier
                                .size(44.dp)
                                .background(
                                    if (!busy && draft.isNotBlank()) Color(0xFF18243A) else Surface2,
                                    CircleShape
                                )
                                .border(1.dp, BorderSoft, CircleShape)
                        ) {
                            Icon(
                                Icons.Default.Send,
                                "إرسال",
                                tint = if (!busy && draft.isNotBlank()) Color(0xFFE8EDF7) else TextMuted,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                    }
                }
            }
        ) { padding ->
            val messages = current?.messages.orEmpty()
            if (messages.isEmpty()) {
                Column(
                    Modifier.fillMaxSize().padding(padding).padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.wormgpt_logo),
                        contentDescription = "WORMGPT",
                        modifier = Modifier
                            .size(72.dp)
                            .clip(CircleShape)
                            .border(1.dp, BorderSoft, CircleShape),
                        contentScale = ContentScale.Crop
                    )
                    Spacer(Modifier.height(22.dp))
                    Text("كيف أقدر أساعدك اليوم؟", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("اكتب سؤالك وابدأ محادثة جديدة مع WORMGPT.", color = mutedText, fontSize = 13.sp)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(padding),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(messages, key = { it.id }) { message ->
                        MessageBubble(message)
                    }
                    if (busy) item {
                        // يظهر على جهة الرد (يسار) مش جهة المستخدم
                        androidx.compose.runtime.CompositionLocalProvider(
                            androidx.compose.ui.platform.LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Ltr
                        ) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
                                Surface(
                                    color = Color(0xFF111114),
                                    shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp, bottomStart = 6.dp, bottomEnd = 20.dp),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, BorderSoft)
                                ) {
                                    Text(
                                        "WORMGPT يكتب الآن…",
                                        color = mutedText,
                                        fontSize = 13.sp,
                                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showSettings) {
        AlertDialog(
            onDismissRequest = { showSettings = false },
            containerColor = panel,
            title = { Text("الإعدادات", color = mainText, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    // الحساب
                    Text("الحساب", color = mutedText, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    Surface(color = panel2, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                        Row(
                            Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.wormgpt_logo),
                                contentDescription = null,
                                modifier = Modifier.size(40.dp).clip(RoundedCornerShape(10.dp)),
                                contentScale = ContentScale.Crop
                            )
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text(store.currentUser() ?: "—", color = mainText, fontWeight = FontWeight.Bold)
                                Text("حساب محلي على هذا الجهاز", color = mutedText, fontSize = 11.sp)
                            }
                        }
                    }

                    Button(
                        onClick = {
                            store.clearSessions()
                            sessions = emptyList()
                            currentId = ""
                            Toast.makeText(context, "تم مسح كل المحادثات", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.fillMaxWidth().height(46.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = panel2, contentColor = mainText)
                    ) {
                        Icon(Icons.Default.DeleteOutline, null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("مسح كل المحادثات")
                    }

                    Button(
                        onClick = {
                            store.deleteAccount()
                            showSettings = false
                            onLogout()
                            Toast.makeText(context, "تم حذف الحساب المحلي", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.fillMaxWidth().height(46.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3A1515), contentColor = Color(0xFFFF8A8A))
                    ) {
                        Icon(Icons.Default.Logout, null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("حذف الحساب")
                    }

                    Divider(color = panel2)

                    // المظهر
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(if (light) Icons.Default.LightMode else Icons.Default.DarkMode, null, tint = Accent)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text("المظهر", color = mainText)
                            Text(if (light) "الوضع الفاتح" else "الوضع الداكن", color = mutedText, fontSize = 12.sp)
                        }
                        Switch(checked = light, onCheckedChange = onThemeChange)
                    }

                    Divider(color = panel2)

                    // اقتراح لتحسين التطبيق
                    Button(
                        onClick = {
                            showSettings = false
                            showSuggestion = true
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .border(1.dp, BorderSoft, RoundedCornerShape(12.dp)),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Surface2,
                            contentColor = TextMain
                        ),
                        elevation = ButtonDefaults.buttonElevation(0.dp)
                    ) {
                        Icon(Icons.Default.Edit, null, modifier = Modifier.size(18.dp), tint = TextMain)
                        Spacer(Modifier.width(8.dp))
                        Text("اقتراح لتحسين التطبيق", fontWeight = FontWeight.Bold)
                    }

                    Text(
                        "مشاركة المحادثة من أيقونات شريط الدردشة. مشاركة التطبيق من القائمة الجانبية.",
                        color = mutedText,
                        fontSize = 11.sp
                    )
                }
            },
            confirmButton = { TextButton(onClick = { showSettings = false }) { Text("تم") } }
        )
    }

    if (showSuggestion) {
        AlertDialog(
            onDismissRequest = { if (!suggestionSending) showSuggestion = false },
            containerColor = panel,
            title = { Text("اقتراح لتحسين التطبيق", color = mainText, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("اكتب اقتراحك وسيصلك للمطور مباشرة.", color = mutedText, fontSize = 13.sp)
                    OutlinedTextField(
                        value = suggestionText,
                        onValueChange = { suggestionText = it },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 120.dp),
                        placeholder = { Text("مثال: أضف خاصية كذا…", color = Color(0xFF5A6170)) },
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Accent,
                            unfocusedBorderColor = panel2,
                            focusedTextColor = mainText,
                            unfocusedTextColor = mainText,
                            cursorColor = Accent
                        )
                    )
                }
            },
            confirmButton = {
                TextButton(
                    enabled = !suggestionSending && suggestionText.trim().length >= 3,
                    onClick = {
                        suggestionSending = true
                        scope.launch {
                            val result = sendSuggestionToBot(context, store.currentUser(), suggestionText.trim())
                            suggestionSending = false
                            if (result.startsWith("OPEN_TG:")) {
                                val bot = result.removePrefix("OPEN_TG:")
                                val encoded = android.net.Uri.encode(suggestionText.trim())
                                val uri = android.net.Uri.parse("https://t.me/$bot?text=$encoded")
                                try {
                                    context.startActivity(Intent(Intent.ACTION_VIEW, uri))
                                    Toast.makeText(context, "افتح تيليجرام وأرسل الرسالة", Toast.LENGTH_LONG).show()
                                } catch (_: Exception) {
                                    Toast.makeText(context, "ثبّت تيليجرام أولاً", Toast.LENGTH_SHORT).show()
                                }
                            } else {
                                Toast.makeText(context, result, Toast.LENGTH_LONG).show()
                            }
                            suggestionText = ""
                            showSuggestion = false
                        }
                    }
                ) {
                    Text(if (suggestionSending) "جاري الإرسال…" else "إرسال")
                }
            },
            dismissButton = {
                TextButton(onClick = { if (!suggestionSending) showSuggestion = false }) {
                    Text("إلغاء")
                }
            }
        )
    }
}

@Composable
private fun MessageBubble(message: ChatMessage) {
    val mine = message.role == "user"
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val light = ctx.getSharedPreferences("wormgpt_store", Context.MODE_PRIVATE).getBoolean("light_theme", false)
    val bubbleText = if (light) LightText else TextMain
    val userBubble = if (light) Color(0xFF1A1A1C) else Color(0xFF1C1C20)
    val assistantBubble = if (light) LightSurface else Color(0xFF111114)

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = if (mine) Arrangement.Start else Arrangement.End
        ) {
            Surface(
                color = if (mine) userBubble else assistantBubble,
                shape = RoundedCornerShape(18.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, BorderSoft),
                modifier = Modifier.widthIn(max = 340.dp)
            ) {
                Column(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (mine) {
                        Text(message.text, color = bubbleText, fontSize = 14.sp, lineHeight = 22.sp)
                    } else {
                        splitReplyParts(message.text).forEach { part ->
                            if (part.code) {
                                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                                    Surface(
                                        color = Color(0xFF090A0D),
                                        shape = RoundedCornerShape(10.dp),
                                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF292A30)),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Column(Modifier.padding(10.dp)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(part.language.uppercase(), color = Color(0xFF9DA3B2), fontSize = 10.sp, modifier = Modifier.weight(1f))
                                                IconButton(
                                                    onClick = {
                                                        val clipboard = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                                        clipboard.setPrimaryClip(ClipData.newPlainText("code", part.text))
                                                        Toast.makeText(ctx, "تم نسخ الكود", Toast.LENGTH_SHORT).show()
                                                    },
                                                    modifier = Modifier.size(28.dp)
                                                ) {
                                                    Icon(Icons.Default.ContentCopy, "نسخ الكود", tint = Color(0xFFBFC5D2), modifier = Modifier.size(15.dp))
                                                }
                                            }
                                            Divider(color = Color(0xFF292A30))
                                            Text(
                                                text = part.text,
                                                color = Color(0xFFE6E8ED),
                                                fontFamily = FontFamily.Monospace,
                                                fontSize = 12.sp,
                                                lineHeight = 18.sp,
                                                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                                textAlign = TextAlign.Start,
                                                softWrap = false
                                            )
                                        }
                                    }
                                }
                            } else {
                                val cleanText = stripMarkdown(part.text)
                                val direction = paragraphDirection(cleanText)
                                CompositionLocalProvider(LocalLayoutDirection provides direction) {
                                    Text(
                                        text = cleanText,
                                        color = bubbleText,
                                        fontSize = 14.sp,
                                        lineHeight = 23.sp,
                                        textAlign = TextAlign.Start,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}



class WormReplyWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val sessionId = inputData.getString("session_id") ?: return Result.failure()
        val message = inputData.getString("message") ?: return Result.failure()
        // Long generations run as a WorkManager foreground task on Android 13-15.
        // The persistent notification is updated to completion when the reply is saved.
        setForeground(createWormForegroundInfo(applicationContext, sessionId))
        if (!hasValidatedInternet(applicationContext)) return Result.retry()

        val store = LocalStore(applicationContext)
        val sessions = store.loadSessions()
        val session = sessions.firstOrNull { it.id == sessionId } ?: return Result.failure()
        val manifestPath = inputData.getString("manifest_path").orEmpty()
        val manifestFile = File(manifestPath)
        val attachmentsRaw = runCatching { if (manifestFile.isFile) manifestFile.readText() else "[]" }.getOrDefault("[]")
        val attachments = runCatching {
            val array = JSONArray(attachmentsRaw)
            (0 until array.length()).mapNotNull { index ->
                val item = array.getJSONObject(index)
                val path = item.getString("path")
                if (!File(path).isFile) null else LocalAttachment(
                    name = item.optString("name", File(path).name),
                    mimeType = item.optString("mimeType", "application/octet-stream"),
                    path = path,
                    size = item.optLong("size", File(path).length()),
                    relativePath = item.optString("relativePath", "")
                )
            }
        }.getOrDefault(emptyList())

        val reply = try {
            WormApi().send(message, session.messages, attachments)
        } catch (error: Exception) {
            // Keep the manifest and attachment files intact across retries.
            return if (runAttemptCount < 8) Result.retry() else {
                val failureText = "حدث خطأ في الاتصال بموقع WORMGPT. تأكد من الإنترنت وحاول مرة أخرى.\n${error.localizedMessage ?: ""}".trim()
                val latest = store.loadSessions().firstOrNull { it.id == sessionId } ?: session
                val failed = latest.copy(
                    messages = latest.messages + ChatMessage(role = "assistant", text = failureText),
                    updated = System.currentTimeMillis()
                )
                store.saveSessions(listOf(failed) + store.loadSessions().filterNot { it.id == sessionId })
                attachments.forEach { File(it.path).delete() }
                manifestFile.delete()
                postCompletionNotification(applicationContext, failureText, sessionId, failed = true)
                Result.success()
            }
        }

        attachments.forEach { File(it.path).delete() }
        manifestFile.delete()
        val latest = store.loadSessions().firstOrNull { it.id == sessionId } ?: session
        val finished = latest.copy(
            messages = latest.messages + ChatMessage(role = "assistant", text = reply),
            updated = System.currentTimeMillis()
        )
        store.saveSessions(listOf(finished) + store.loadSessions().filterNot { it.id == sessionId })
        // Notify only after the reply is saved, and only if the app is not visible.
        // Completion uses a different notification ID/channel from the required FGS notice,
        // so WorkManager cannot remove it while stopping the foreground service.
        postCompletionNotification(applicationContext, reply, sessionId, failed = false)
        return Result.success()
    }
}

private const val WORM_PROGRESS_CHANNEL = "wormgpt_progress_v2"
private const val WORM_COMPLETION_CHANNEL = "wormgpt_completion_v2"

private fun ensureWormNotificationChannels(context: Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        // A quiet, low-priority channel is required while WorkManager runs a foreground task.
        manager.createNotificationChannel(
            NotificationChannel(
                WORM_PROGRESS_CHANNEL,
                "حالة توليد WORMGPT",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "إشعار هادئ مطلوب لاستمرار التوليد في الخلفية"
                setShowBadge(false)
                setSound(null, null)
                enableVibration(false)
            }
        )
        // Completion is a separate, user-visible alert channel.
        manager.createNotificationChannel(
            NotificationChannel(
                WORM_COMPLETION_CHANNEL,
                "اكتمال توليد WORMGPT",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "يظهر عند اكتمال الرد أثناء وجودك خارج التطبيق"
                setShowBadge(true)
            }
        )
    }
}

private fun wormNotificationId(sessionId: String): Int = 2000 + (sessionId.hashCode() and 0x0000FFFF)
private fun wormCompletionNotificationId(sessionId: String): Int = 100000 + (sessionId.hashCode() and 0x0000FFFF)

private fun createWormForegroundInfo(context: Context, sessionId: String): ForegroundInfo {
    ensureWormNotificationChannels(context)
    val notification = NotificationCompat.Builder(context, WORM_PROGRESS_CHANNEL)
        .setSmallIcon(android.R.drawable.stat_notify_sync)
        .setContentTitle("WORMGPT")
        .setContentText("جاري توليد الرد…")
        .setOngoing(true)
        .setOnlyAlertOnce(true)
        .setSilent(true)
        .setCategory(NotificationCompat.CATEGORY_PROGRESS)
        .build()
    val id = wormNotificationId(sessionId)
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        ForegroundInfo(id, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
    } else ForegroundInfo(id, notification)
}

private fun isWormAppVisible(): Boolean = try {
    ProcessLifecycleOwner.get().lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)
} catch (_: Exception) {
    // If lifecycle state cannot be determined, prefer not to interrupt the user.
    true
}

private fun postCompletionNotification(
    context: Context,
    reply: String,
    sessionId: String,
    failed: Boolean
) {
    // The user asked for the completion alert only after leaving the app.
    if (isWormAppVisible()) return
    ensureWormNotificationChannels(context)
    if (Build.VERSION.SDK_INT >= 33 &&
        ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
    ) return
    val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    if (!NotificationManagerCompatShim.areNotificationsEnabled(context)) return
    val openApp = PendingIntent.getActivity(
        context,
        sessionId.hashCode(),
        Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
    val notification = NotificationCompat.Builder(context, WORM_COMPLETION_CHANNEL)
        .setSmallIcon(R.drawable.ic_stat_worm)
        .setContentTitle(if (failed) "تعذر إكمال توليد WORMGPT" else "اكتمل توليد WORMGPT")
        .setContentText(if (failed) "تعذر إكمال الرد. اضغط لفتح المحادثة." else "اكتمل توليد ردك. اضغط لعرضه.")
        .setStyle(NotificationCompat.BigTextStyle().bigText(reply.take(180)))
        .setContentIntent(openApp)
        .setAutoCancel(true)
        .setOngoing(false)
        .setCategory(NotificationCompat.CATEGORY_MESSAGE)
        .build()
    // Do not reuse WorkManager's foreground notification ID: it is removed on worker shutdown.
    manager.notify(wormCompletionNotificationId(sessionId), notification)
}

private object NotificationManagerCompatShim {
    fun areNotificationsEnabled(context: Context): Boolean =
        androidx.core.app.NotificationManagerCompat.from(context).areNotificationsEnabled()
}

# WorkManager instantiates this worker by class name.
-keep class com.wormgpt.ai.WormReplyWorker { public <init>(...); *; }
-keep class com.wormgpt.ai.MainActivity { *; }
# Preserve runtime annotations and generic signatures used by AndroidX/Kotlin.
-keepattributes RuntimeVisibleAnnotations,RuntimeVisibleParameterAnnotations,AnnotationDefault,Signature,InnerClasses,EnclosingMethod
-dontwarn javax.annotation.**
